# https://firebase.google.com/support/release-notes/ios
def firebase_sdk_version!()
  '9.5.0'
end
